package MyUtilities.math;

public class Operations {

    public int add(int a, int b){
        int suma = a + b;
        return suma;
    }
    
}
